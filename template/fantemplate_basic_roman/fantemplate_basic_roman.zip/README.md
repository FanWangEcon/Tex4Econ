Short file, for documents that require roman font, double space, 11 or 12 point font.
